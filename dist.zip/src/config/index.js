import corsConfig from './cors';
import routerConfig from './router';
import compressionConfig from './compression';

export {
  corsConfig,
  routerConfig,
  compressionConfig,
};
