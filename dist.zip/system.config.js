/* eslint-disable */

System.config({
  paths: {
    '@/*': './src/*',
  },
});
