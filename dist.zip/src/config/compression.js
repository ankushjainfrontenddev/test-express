export default {
  level: 9,
};
