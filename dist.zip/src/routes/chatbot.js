import { Router } from 'express';

import * as chatbotController from '@/controllers/chatbot';
import * as homeController from '@/controllers/home';
const router = Router();

router.get('/health', homeController.healthCheck);
router.get('/getresponse', chatbotController.getResponse);
router.post('/get-response', chatbotController.getResponse);
router.post('/create-user', chatbotController.cretaeUser);
// router.route('/')
//     .get(isAuthenticated, validate(tweetValidations.listTweetsRules), chatbotController.getTweets)
//     .post(isAuthenticated, validate(tweetValidations.createTweetRules), chatbotController.createTweet);

// router.route('/:id')
//     .get(cache('Tweet', 'req.params.id'), tweetController.getTweetById)
//     .delete(isAuthenticated, tweetController.deleteTweet);

export default router;
